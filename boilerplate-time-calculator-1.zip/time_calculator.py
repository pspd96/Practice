def add_time(start, duration,day=''):
  day_of_week=['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday']
  startt=start.split(' ')
  time=startt[0]
  ap=startt[1]
  septime=time.split(':')
  durtime=duration.split(':')
  realhr=0
  if ap == 'AM':
    aorp=''
    mins=int(septime[1])+int(durtime[1])
    added_hr=(mins / 60) - (((mins%60))/60)
    
    if added_hr>0:
      currmin=int(mins-(60*added_hr))
    else:
      currmin=int(mins)
    if septime[0]=='12':
      thours=int(septime[0]) + int(durtime[0]) +added_hr -12
    else:
      thours=int(septime[0]) + int(durtime[0]) +added_hr
    
    
    if thours>=24:
      hrday = thours % 24
    else:
      hrday = thours
    if hrday>12:
      realhr=int(hrday-12)
      aorp='PM'
    if hrday==12:
      realhr=12
      aorp='PM'
    if hrday<12:
      realhr=int(hrday)
      aorp='AM'
    if hrday==0:
      realhr=12

    days =int (thours / 24)  
    if days<2:
      dayString=' (next day)'
    if days>=2:
      dayString=' ('+str(int(days))+' days later)'
    if days<1:
      dayString=''


    if day.lower() in (name.lower() for name in day_of_week):
      rilday=0
      numbday=0
      dday=0
      for d in day_of_week:
        if day.lower() == d.lower():
          numbday=day_of_week.index(d)+1
        rilday=(numbday+days)
        if rilday>=7:
          dday=rilday%7-1
        if rilday<7:
          dday=rilday-1
      if currmin<10:
        new_time=str(realhr)+':0'+str(currmin)+' '+aorp+', '+day_of_week[dday]+dayString
      else:
        new_time=str(realhr)+':'+str(currmin)+' '+aorp+', '+day_of_week[dday]+dayString
    else:
      rilday=0
      numbday=0
      dday=0
      for d in day_of_week:
        if day.lower() == d.lower():
          numbday=day_of_week.index(d)+1
        rilday=(numbday+days)
        if rilday>=7:
          dday=rilday%7-1
        if rilday<7:
          dday=rilday-1
      if currmin<10:
        new_time=str(realhr)+':0'+str(currmin)+' '+aorp+dayString
      else:
        new_time=str(realhr)+':'+str(currmin)+' '+aorp+dayString
      
    

  if ap == 'PM':
    aorp=''
    mins=int(septime[1])+int(durtime[1])
    added_hr=(mins / 60) - (((mins%60))/60)
    if added_hr>0:
      currmin=int(mins-(60*added_hr))
    else:
      currmin=int(mins)
    thours=int(septime[0]) + 12 + int(durtime[0]) +added_hr
    
    if thours>=24:
      hrday = thours % 24
    else:
      hrday = thours
    if hrday>12:
      realhr=int(hrday-12)
      aorp='PM'
    if hrday==12:
      realhr=12
      aorp='PM'
    if hrday<12:
      realhr=int(hrday)
      aorp='AM'
    if hrday==0:
      realhr=12
    
    days =int (thours / 24)  
    if days<2:
      dayString=' (next day)'
    if days>=2:
      dayString=' ('+str(int(days))+' days later)'
    if days<1:
      dayString=''

    if day.lower() in (name.lower() for name in day_of_week):
      rilday=0
      numbday=0
      dday=0
      for d in day_of_week:
        if day.lower() == d.lower():
          numbday=day_of_week.index(d)+1
        rilday=(numbday+days)
        if rilday>=7:
          dday=rilday%7-1
        if rilday<7:
          dday=rilday-1
      if currmin<10:
        new_time=str(realhr)+':0'+str(currmin)+' '+aorp+', '+day_of_week[dday]+dayString
      else:
        new_time=str(realhr)+':'+str(currmin)+' '+aorp+', '+day_of_week[dday]+dayString
    else:
      rilday=0
      numbday=0
      dday=0
      for d in day_of_week:
        if day.lower() == d.lower():
          numbday=day_of_week.index(d)+1
        rilday=(numbday+days)
        if rilday>=7:
          dday=rilday%7-1
        if rilday<7:
          dday=rilday-1
      if currmin<10:
        new_time=str(realhr)+':0'+str(currmin)+' '+aorp+dayString
      else:
        new_time=str(realhr)+':'+str(currmin)+' '+aorp+dayString
    





  return new_time