class Category:
  def __init__(self,name):
    self.name=name
    self.ledger=list()
  def deposit(self,amount,description=''):
    self.ledger.append({'amount':amount, 'description':description})
    
  def withdraw(self,amount,description=''):
    if self.check_funds(amount) == True:
      self.ledger.append({'amount':-amount, 'description':description})
      return True
    else:
      return False
    
  def get_balance(self):
    result=0
    for x in self.ledger:
      result +=x['amount']

    return result 


  def transfer(self,amount,category):
    if self.check_funds(amount) == True:
      
      withdrawDescription = "Transfer to " + category.name
      self.withdraw(amount,withdrawDescription)
      
      depositDescription = "Transfer from " + self.name
      category.deposit(amount, depositDescription)
      return True
    else:
      return False 

  def check_funds(self,amount):
    result=0
    for x in self.ledger:
      result +=x['amount']
    if amount> result:
      return False
    else:
      return True
  
  def spent(self):
    total=0
    for x in self.ledger:
      if x["amount"]<0:
        total+=x['amount']
    return total


  def __str__(self):
        title = f"{self.name:*^30}\n"
        items = ""
        total = 0
        for x in self.ledger:
          items += f"{x['description'][0:23]:23}" + f"{x['amount']:>7.2f}" + '\n'
          total += x['amount']

        output = title + items + "Total: " + str(total)
        return output
    




def create_spend_chart(categories):
    result = 'Percentage spent by category\n'

    total = sum(x.spent() for x in categories)
    percentages = [(x.spent()/total)//0.01 for x in categories]
    for x in range(100, -10, -10):
        result = result + str(x).rjust(3, " ") + '|'
        for y in percentages:
            if y >= x:
                result = result + ' o '
            else:
                result = result + '   '
        result = result + ' \n'
    result = result + '    ' + '-'*len(percentages)*3 + '-\n'
    maxLength = max(len(x.name) for x in categories)
    for x in range(maxLength):
        result = result + '    '
        for y in categories:
            if x < len(y.name):
                result = result + ' ' + y.name[x] + ' '
            else:
                result = result + '   '
        result = result + ' \n'
    return result.rstrip() +'  '