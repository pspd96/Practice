def arithmetic_arranger(problems,send=None):
    line3 = ''
    line1 = ''
    line2 = ''
    result = ''
    count = 0
    if len(problems) > 5:
      return 'Error: Too many problems.'
      
    for exp in problems:
      calc=''
      numlists = exp.split()
      num1 = numlists[0]
      num2 = numlists[2]
      operator = numlists[1]
      
      if len(num1)>4 or len(num2)>4:
        return 'Error: Numbers cannot be more than four digits.'
      if not num1.isnumeric() or not num2.isnumeric():
        return 'Error: Numbers must only contain digits.'  
      if operator == '+' or operator == '-':
        max_length = max(len(num1),len(num2)) + 2
        top = str(num1).rjust(max_length)
        bot = operator + str(num2).rjust(max_length-1)
        line = max_length * '-'
        if send==True and operator=='+':
          tots = int(num1) + int(num2)
          calc = str(tots).rjust(max_length)
        if send==True and operator=='-':
          totd = int(num1) - int(num2)
          calc = str(totd).rjust(max_length)
      else:
        return "Error: Operator must be '+' or '-'."
      count = count + 1
      
      if count <len(problems):
        line1 += top + '    '
        line2 += bot + '    '
        line3 += line + '    '
        result += calc + '    '
      if count == len(problems):
        line1 += top
        line2 += bot
        line3 += line
        result += calc

      line1.strip()
      line3.strip()
      line2.strip()
      result.strip()


      
    if send==True:
      arranged_problems = line1+'\n'+line2 +'\n'+line3+'\n'+result
    else:
      arranged_problems = line1+'\n'+line2 +'\n'+line3
    return arranged_problems