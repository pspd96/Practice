import copy
import random
# Consider using the modules imported above.

class Hat:
  def __init__(self,**kwargs):
    self.contents=[]
    for key,value in kwargs.items():
      x = value
      while x >0:
        self.contents.append(key)
        x-=1

  def draw(self,num_balls):
    inst = copy.copy(self.contents)
    x = num_balls
    drawn=[]
    while x > 0:
      sel_num = len(self.contents)
      if sel_num < x :
        self.contents = inst
      else:
        selector = random.randint(0, sel_num-1)
        drawn.append(self.contents[selector])
        self.contents.pop(selector)
      x-=1
    return drawn




def experiment(hat, expected_balls, num_balls_drawn, num_experiments):
  M=0
  N=num_experiments
  exp=[]
  expdict = dict(expected_balls)

  for key,value in expected_balls.items():
      while value>0:
        exp.append(key)
        value-=1

  while num_experiments > 0:
      dhat = copy.deepcopy(hat)
      result = dhat.draw(num_balls_drawn)
      check=0
      
      for key, value in expdict.items():
        if result.count(key) >= value:
          check+=1
      if check>= len(expdict):
        M+=1

      num_experiments-=1

      
    
  return M/N